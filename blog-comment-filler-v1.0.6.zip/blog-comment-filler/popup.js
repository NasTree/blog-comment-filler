const $ = (id) => document.getElementById(id);

chrome.storage.sync.get(
  { nickname: "", email: "", website: "", autofill: false },
  (data) => {
    $("nickname").value = data.nickname || "";
    $("email").value = data.email || "";
    $("website").value = data.website || "";
    $("autofill").checked = !!data.autofill;
  }
);

$("save").addEventListener("click", () => {
  const data = {
    nickname: $("nickname").value.trim(),
    email: $("email").value.trim(),
    website: $("website").value.trim(),
    autofill: $("autofill").checked,
  };
  chrome.storage.sync.set(data, () => {
    $("status").textContent = "已保存，去博客评论区点“信息填充”试试。";
    setTimeout(() => { $("status").textContent = ""; }, 3000);
  });
});
