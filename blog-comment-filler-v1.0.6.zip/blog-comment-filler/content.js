// 博客评论一键填充 content script
// 适配：WordPress、Typecho、Hexo、Hugo、Ghost、Waline、Valine、Gitalk 等
// 原理：按字段名 / id / type / placeholder 识别昵称、邮箱、网址三类输入框，
// 在评论表单标题旁插入一个填充按钮，点一下从 chrome.storage.sync 读取已保存的信息填进去。

const BUTTON_CLASS = "blog-comment-filler-btn";
const DONE_ATTR = "data-bcf-done";

const NAME_PATTERNS = [
  /author/i, /nickname/i, /nick/i, /name/i, /user/i, /comment_author/i,
  /昵称/, /名字/, /姓名/, /称呼/,
];
const EMAIL_PATTERNS = [
  /email/i, /mail/i, /comment_email/i, /邮箱/, /邮件/,
];
const URL_PATTERNS = [
  /url/i, /website/i, /site/i, /homepage/i, /comment_url/i, /author_url/i,
  /网址/, /网站/, /主页/, /博客/,
];

function fieldText(el) {
  return [
    el.name || "",
    el.id || "",
    el.getAttribute("aria-label") || "",
    el.placeholder || "",
    el.className || "",
  ].join(" ");
}

function matchField(el, patterns) {
  return patterns.some((p) => p.test(fieldText(el)));
}

function findFields(root) {
  const visible = Array.from(root.querySelectorAll("input")).filter((el) => {
    const t = (el.type || "text").toLowerCase();
    if (["hidden", "submit", "button", "checkbox", "radio", "file"].includes(t)) return false;
    return true;
  });

  let nameEl = visible.find((el) => (el.type || "").toLowerCase() === "text" && matchField(el, NAME_PATTERNS));
  let emailEl =
    visible.find((el) => (el.type || "").toLowerCase() === "email") ||
    visible.find((el) => matchField(el, EMAIL_PATTERNS));
  let urlEl =
    visible.find((el) => (el.type || "").toLowerCase() === "url") ||
    visible.find((el) => matchField(el, URL_PATTERNS));

  // 兜底：按输入框在表单里的顺序推断（WordPress/Typecho 常见顺序：昵称、邮箱、网址）
  if (!nameEl || !emailEl || !urlEl) {
    const textInputs = visible.filter((el) => ["text", "email", "url", ""].includes((el.type || "").toLowerCase()));
    if (textInputs.length >= 3 && (!nameEl || !emailEl || !urlEl)) {
      nameEl = nameEl || textInputs[0];
      emailEl = emailEl || textInputs[1];
      urlEl = urlEl || textInputs[2];
    }
  }
  return { nameEl, emailEl, urlEl };
}

function setValue(el, value) {
  if (!el || !value) return false;
  const setter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value")?.set
    || Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, "value")?.set;
  if (setter) setter.call(el, value);
  else el.value = value;
  el.dispatchEvent(new Event("input", { bubbles: true }));
  el.dispatchEvent(new Event("change", { bubbles: true }));
  return true;
}

// 黄色：macOS 窗口黄色圆点同色 #FFBD2E
const YELLOW = "#FFBD2E";
const MODERN_FONT = "'Inter', system-ui, -apple-system, 'Segoe UI', Roboto, 'PingFang SC', 'Microsoft YaHei', sans-serif";

function showToast(msg) {
  const toast = document.createElement("div");
  toast.textContent = msg;
  Object.assign(toast.style, {
    position: "fixed", right: "16px", bottom: "16px", zIndex: "2147483647",
    background: YELLOW, color: "#1f1f1f", padding: "12px 18px",
    borderRadius: "12px", fontSize: "14px", fontWeight: "500",
    fontFamily: MODERN_FONT, letterSpacing: "0.02em",
    boxShadow: "0 4px 16px rgba(0,0,0,.25)",
  });
  document.body.appendChild(toast);
  setTimeout(() => toast.remove(), 2500);
}

function fillForm(form) {
  chrome.storage.sync.get({ nickname: "", email: "", website: "", autofill: false }, (data) => {
    if (!data.nickname && !data.email && !data.website) {
      showToast("还没填信息：点浏览器工具栏的插件图标，先填昵称、邮箱、网址。");
      return;
    }
    const { nameEl, emailEl, urlEl } = findFields(form);
    const filled = [
      setValue(nameEl, data.nickname),
      setValue(emailEl, data.email),
      setValue(urlEl, data.website),
    ].filter(Boolean).length;
    if (filled > 0) showToast(`已填充 ${filled} 项信息，只管写评论吧。`);
    else showToast("没找到昵称 / 邮箱 / 网址输入框，这个评论系统可能不适配。");
  });
}

function makeButton(form) {
  const btn = document.createElement("button");
  btn.type = "button";
  btn.className = BUTTON_CLASS;
  // 用插件 logo 代替原来的 ✍️ 表情
  const img = document.createElement("img");
  img.src = chrome.runtime.getURL("icons/icon32.png");
  img.alt = "";
  Object.assign(img.style, { width: "18px", height: "18px", borderRadius: "4px", display: "block" });
  btn.appendChild(img);
  btn.appendChild(document.createTextNode("信息填充"));
  Object.assign(btn.style, {
    display: "inline-flex", alignItems: "center", gap: "6px", flexShrink: "0",
    marginLeft: "0", padding: "6px 14px", fontSize: "13px", fontWeight: "600",
    fontFamily: MODERN_FONT, letterSpacing: "0.02em",
    border: `1px solid ${YELLOW}`, borderRadius: "8px", background: YELLOW,
    color: "#1f1f1f", cursor: "pointer", verticalAlign: "middle", whiteSpace: "nowrap",
  });
  btn.addEventListener("click", (e) => { e.preventDefault(); fillForm(form); });
  return btn;
}

function attachToForm(form) {
  if (!form || form.getAttribute(DONE_ATTR)) return;
  const { nameEl, emailEl, urlEl } = findFields(form);
  if (!nameEl && !emailEl && !urlEl) return;
  form.setAttribute(DONE_ATTR, "1");

  // 位置：优先放在“提交评论”按钮左边 —— 提交按钮那一行在所有博客里
  // 都在表单底部、评论框外面，不会跑进评论框里，也不会被标题的样式带偏。
  // 兜底才用标题右侧，标题实在找不到才放表单最前面。
  const submit =
    form.querySelector('input[type="submit"], button[type="submit"], #submit, [id*="submit" i], .submit-btn, .comment-submit') ||
    Array.from(form.querySelectorAll("button, input")).find((el) =>
      /提交|发表|发布|评论/.test(el.value || el.textContent || "")
    );
  if (submit && submit.parentNode) {
    const btn = makeButton(form);
    btn.style.marginRight = "10px";
    submit.parentNode.insertBefore(btn, submit);
  } else {
    const title =
      form.querySelector("#reply-title, .comment-reply-title, h2, h3") ||
      form.closest("#respond")?.querySelector("#reply-title, .comment-reply-title, h2, h3") ||
      document.querySelector("#respond #reply-title, #respond .comment-reply-title");
    if (title && title.parentNode) {
      // 不直接改标题本身的样式（有些博客标题在评论框内部），
      // 把按钮插到标题后面、同一个父级里，并让父级用 flex 同行排列
      title.style.display = "inline-flex";
      title.style.alignItems = "center";
      const btn = makeButton(form);
      btn.style.marginLeft = "10px";
      title.parentNode.insertBefore(btn, title.nextSibling);
    } else {
      // 没有标题就插到表单最前面
      form.insertBefore(makeButton(form), form.firstChild);
    }
  }

  chrome.storage.sync.get({ autofill: false }, (data) => {
    if (data.autofill) fillForm(form);
  });
}

function scan() {
  // 常见评论表单：WordPress #commentform、Typecho #comment-form、通用 form
  const forms = new Set();
  document.querySelectorAll("form").forEach((f) => {
    const { nameEl, emailEl, urlEl } = findFields(f);
    const hasComment = !!f.querySelector('textarea[name="comment"], textarea#comment, textarea');
    if ((nameEl || emailEl || urlEl) && hasComment) forms.add(f);
  });
  // 有些评论区没有 <form>（Waline / Valine 等用 div 渲染），按输入框组兜底
  document.querySelectorAll("#respond, .comment-form, #comment-form, .wl-comment, .vcomment").forEach((box) => {
    const form = box.querySelector("form") || box;
    if (form.tagName === "FORM") forms.add(form);
  });
  forms.forEach(attachToForm);
}

scan();
new MutationObserver(() => scan()).observe(document.documentElement, { childList: true, subtree: true });
